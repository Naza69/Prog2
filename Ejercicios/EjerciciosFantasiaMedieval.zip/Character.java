public interface Character {
  public float attack();

  public void defend();
}