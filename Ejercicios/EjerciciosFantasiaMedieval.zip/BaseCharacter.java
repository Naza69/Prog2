public abstract class BaseCharacter implements Character {
  private int level;
  private String name;
  private float healthPoints;

  public BaseCharacter(int level, String name, float healthpoints) {
  }

  public float attack() {
    float damage = level * 0.2f;
    System.out.println(name + " ataca inflingiendo " + damage + " puntos de daño");
    return damage;
  }

  public void defend(float damage) {
    System.out.println(getName() + "Se defiende!");
    if (getHealthPoints() - damage <= 0) {
      System.out.println("El personaje ha muerto");
      setHealthPoints(0);
    } else if (getHealthPoints() - damage > 0) {
      System.out.println("El personaje se ha quedado con " + (getHealthPoints() - damage) + " puntos de vida");
      setHealthPoints(getHealthPoints() - damage);
    }

  }

  public int getLevel() {
    return level;
  }

  public String getName() {
    return name;
  }

  public float getHealthPoints() {
    return healthPoints;
  }

  public void setName(String newName) {
    this.name = newName;
  }

  public void setLevel(int newLevel) {
    this.level = newLevel;
  }

  public void setHealthPoints(float newHealthPoints) {
    this.healthPoints = newHealthPoints;
  }

}