public class Warrior extends BaseCharacter {
  private String sword;

  public Warrior(int level, String name, int healthPoints, String sword) {
    super(level, name, healthPoints);
    this.sword = sword;
  }

  @Override
  public float attack() {
    float damage = getLevel() * 0.5f;
    System.out
        .println("El guerrero " + getName() + " blande su espada y ataca inflingiendo " + damage + " puntos de daño");
    return damage;
  }

  @Override
  public void defend(float damage) {
    System.out.println("El guerrero " + getName() + "Se defiende!");
    if (getHealthPoints() - damage <= 0) {
      System.out.println("El guerrero ha muerto");
      setHealthPoints(0);
    } else if (getHealthPoints() - damage > 0) {
      System.out.println("El guerrero se ha quedado con " + (getHealthPoints() - damage) + " puntos de vida");
      setHealthPoints(getHealthPoints() - damage);
    }

  }
}