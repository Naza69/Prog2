public class Rogue extends BaseCharacter {
  private int goldStolen;
  private String shortBlade;

  public Rogue(int level, String name, int healthPoints, int goldStolen) {
    super(level, name, healthPoints);
    this.goldStolen = goldStolen;
    this.shortBlade = shortBlade;
  }

  @Override
  public float attack() {
    float damage = getLevel() * 0.3f;
    System.out
        .println(
            "El guerrero " + getName() + " blande su cuchillo corto y ataca inflingiendo " + damage
                + " puntos de daño");
    return damage;
  }

  @Override
  public void defend(float damage) {
    System.out.println("El picaro " + getName() + "Se defiende!");
    if (getHealthPoints() - damage <= 0) {
      System.out.println("El picaro ha muerto");
      setHealthPoints(0);
    } else if (getHealthPoints() - damage > 0) {
      System.out.println("El picaro se ha quedado con " + (getHealthPoints() - damage) + " puntos de vida");
      setHealthPoints(getHealthPoints() - damage);
    }
  }
}