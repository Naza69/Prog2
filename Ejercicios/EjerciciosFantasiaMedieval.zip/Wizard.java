public class Wizard extends BaseCharacter {
  private int mana;

  public Wizard(int level, String name, int healthPoints, int mana) {
    super(level, name, healthPoints);
    this.mana = mana;
  }

  @Override
  public float attack() {
    float damage = getLevel() * 0.5f + (getMana() / 2);
    System.out
        .println("El mago " + getName() + " genera un hechizo y ataca inflingiendo " + damage + " puntos de daño");
    return damage;
  }

  @Override
  public void defend(float damage) {
    System.out.println("El mago " + getName() + "Se defiende!");
    if (getHealthPoints() - damage <= 0) {
      System.out.println("El mago ha muerto");
      setHealthPoints(0);
    } else if (getHealthPoints() - damage > 0) {
      System.out.println("El mago se ha quedado con " + (getHealthPoints() - damage) + " puntos de vida");
      setHealthPoints(getHealthPoints() - damage);
    }
  }

  public int getMana() {
    return mana;
  }

  public void setMana(int newMana) {
    this.mana = newMana;
  }
}