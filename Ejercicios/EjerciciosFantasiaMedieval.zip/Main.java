public class Main {
  public static void main(String[] args) {
    Warrior SirArthur = new Warrior(10, "Arturo", 100, "Espada de acero");
    Wizard Merlin = new Wizard(50, "Merlin", 130, 200);
    Rogue Nadia = new Rogue(7, "Nadia", 90, 500);

    Merlin.defend(SirArthur.attack());
    SirArthur.defend(Merlin.attack());
    Nadia.defend(SirArthur.attack());
  }
}